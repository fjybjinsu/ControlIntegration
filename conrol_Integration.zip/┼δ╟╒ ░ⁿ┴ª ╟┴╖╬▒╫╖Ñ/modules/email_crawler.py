import re
import os
import json
import math
from urllib import parse
from datetime import datetime

import requests
from bs4 import BeautifulSoup


# requests 모듈 InsecureRequestWarning 에러 출력 방지
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)


class LoginError(Exception):
    def __init__(self):
        super().__init__("Login failed!")


class SessionError(Exception):
    def __init__(self):
        super().__init__("You must be logged!")


class EmailCrawler():
    def __init__(self, user_id, user_pw, domain="army.mil"):
        self.__session = None
        self.__headers = {
            "Host": "[마스킹]",
            "Origin": "[마스킹]",
            "Referer": "[마스킹]",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.3"        
        }
        self.__user_id = user_id
        self.__user_pw = user_pw
        self.__domain = domain
        self.__auto_login = False
        self.__filename_regex = re.compile(r"; filename\=\"(.*)\"")
   
    def set_auto_login(self, boolean):
        if isinstance(boolean, bool):
            self.__auto_login = boolean
            return True
        else:
            return False
    
    def login(self):
        session = requests.session()
        
        response = session.get("[마스킹]", headers=self.__headers, verify=False)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "html.parser")
            csrf = soup.select_one("#wrap > form > input[type=hidden]")["value"]
            data = {
                "_csrf": csrf,
                "j_username": f"{self.__user_id}@{self.__domain}",
                "username": self.__user_id,
                "domain": self.__domain,
                "j_password": self.__user_pw,
                "password": ""       
            }
            response = session.post("[마스킹]", headers=self.__headers, data=data, verify=False)
            if response.status_code == 200 and "아이디 또는 비밀번호를 다시 확인하세요" not in response.text:
                self.__session = session
                return True
            else:
                return False
        else:
            raise LoginError
            return False
    
    def get_login_user_information(self):
        if not self.__session:
            raise SessionError
            return False
        else:
            ceiled_timestamp = math.ceil(datetime.now().timestamp() * 100)
            response = self.__session.get(f"[마스킹]?_={ceiled_timestamp}", headers=self.__headers, verify=False)
            if response.url == "[마스킹]" and self.__auto_login:
                self.login(self.__user_id, self.__user_pw, self.__domain)
                return self.get_all_mails()
            elif response.url != "[마스킹]/login" and response.status_code == 200:
                return json.loads(response.text)
            else:
                raise SessionError
                return False
    
    def get_all_mails(self):
        if not self.__session:
            raise SessionError
            return False
        else:
            ceiled_timestamp = math.ceil(datetime.now().timestamp() * 100)
            data = {
                "_method": "GET",
                "_": ceiled_timestamp
            }
            response = self.__session.post("[마스킹][마스킹]", headers=self.__headers, data=data, verify=False)
            # 세션 만료로 인해 로그인 페이지로 이동되었을 경우, 로그인 및 메일 받기 재시도
            if response.url == "[마스킹]/login" and self.__auto_login:
                self.login(self.__user_id, self.__user_pw, self.__domain)
                return self.get_all_mails()
            elif response.url != "[마스킹]/login" and response.status_code == 200:
                return json.loads(response.text)
            else:
                raise SessionError
                return False
    
    def get_mail_details(self, mail_index):
        if not self.__session:
            raise SessionError
            return False
        else:
            data = {
                "_method": "GET",
                "currentPage": 1,
                "perPage": 20,
                "sortField": "M_TIME",
                "sortOrder": "DESC"
            }
            response = self.__session.post(f"[마스킹]/[마스킹]/{mail_index}", headers=self.__headers, data=data, verify=False)
            if response.url == "[마스킹]/login" and self.__auto_login:
                self.login(self.__user_id, self.__user_pw, self.__domain)
                return self.get_mail_details()
            elif response.url != "[마스킹]/login" and response.status_code == 200:
                return json.loads(response.text)
            else:
                raise SessionError
                return False
    
    def download_attachment(self, mail_index, attachment_num, path=os.getcwd()):
        if not self.__session:
            print("[-] Must be Loggined!!!")
            return False
        else:
            response = self.__session.get(f"[마스킹]/[마스킹]", headers=self.__headers, stream=True, verify=False)
            if response.url == "[마스킹]/login" and self.__auto_login:
                self.login(self.__user_id, self.__user_pw, self.__domain)
                return self.download_attachment(mail_index, attachment_num, path)
            elif response.url != "[마스킹]/login" and response.status_code == 200:
                file_name = parse.unquote(self.__filename_regex.findall(response.headers["Content-Disposition"])[0])
                file_path = os.path.join(path, file_name)
                with open(file_path, "wb") as file:
                    for chunk in response.iter_content(1024*1024):
                        file.write(chunk)
                return file_path
            else:
                raise SessionError
                return False
            
    
    def mail_parser(self, mails):
        pass
        # 발신자: mail["M_SENDER"]
        # 수신자: mail["M_TO"]
        # 제목: mail["M_TITLE"]
        # 내용: mail["M_CONTENT"]
        # 날짜: mail["M_TIME"]
        # 확인 유무: mail["M_ISREAD"] -> "Y" / "N"