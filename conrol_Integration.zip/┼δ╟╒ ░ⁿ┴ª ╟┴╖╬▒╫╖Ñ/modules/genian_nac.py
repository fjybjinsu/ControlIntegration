import base64
from datetime import datetime
import re
from urllib import parse

from bs4 import BeautifulSoup
import lxml
import requests

# requests 모듈 InsecureRequestWarning 출력 방지
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)


class LoginError(Exception):
    def __init__(self):
        super().__init__("Login failed!")


class SessionError(Exception):
    def __init__(self):
        super().__init__("You must be logged!")


class GenianNAC():
    def __init__(self, base_url, user_id, user_pw):
        self.__session = None
        self.__base_url = base_url
        self.__user_id = user_id
        self.__user_pw = user_pw
        self.__auto_login = False
        self.__csrf_regex = re.compile(r"CSRF_NONCE\=(.*)")
    
    def set_auto_login(self, boolean):
        if isinstance(boolean, bool):
            self.__auto_login = boolean
            return True
        else:
            return False
    
    def login(self):
        session = requests.Session()
        response = session.get(parse.urljoin(self.__base_url, "/mc2/faces/adminlogin.xhtml"), verify=False)
        if response.status_code != 200:
            return False
        
        user_credential = base64.b64encode(f'userid={base64.b64encode(self.__user_id.encode("utf-8")).decode("utf-8")}&passwd={base64.b64encode(self.__user_pw.encode("utf-8")).decode("utf-8")}'.encode("utf-8")).decode("utf-8")
        login_data = {
            "cred": user_credential,
            "browserTimeZone": "Asia/Seoul",
            "forceLogin": "true",
            "locale": "ko"
        }
        response = session.post(parse.urljoin(self.__base_url, "/mc2/rest/sessions"), json=login_data, verify=False)
        if response.status_code != 200:
            return False
        
        if response.json()["authResult"] == False:
            return False
        else:
            self.__session = session
            return True
    
    """
        Returned Data Format
        [
            {
                "node_name": <node_name>,           → span#form1:dataTable1:0:txt_nameCol > span
                "node_ip": <node_ip>,               → a#form1:dataTable1:0:lnk_ipCol
                "node_mac": <node_mac>,             → span#form1:dataTable1:0:txt_macCol2
                "node_platform": <node_platform>,   → a#form1:dataTable1:0:lnk_platformCol
                "node_status": <node_status>        → span#form1:dataTable1:0:txt_nodestatCol > i 
            }, 
            ...
        ]
    
    """
    def get_sensor_information(self):
        results = []
        
        if not self.__session:
            return False
        
        response = self.__session.get(parse.urljoin(self.__base_url, "/mc2/faces/monitor/nodeMgmt.xhtml?nid=All&genidev=2"), verify=False)
        if response.status_code != 200:
            return False
        
        soup = BeautifulSoup(response.text, "html.parser")
        all_datas = soup.select_one("tbody#form1\:dataTable1_data")
        
        data_counts = len(all_datas.select("td.checkcol"))
        for index in range(data_counts):
            host_name = all_datas.select_one(f"span#form1\:dataTable1\:{index}\:txt_nameCol").text.strip()
            if "(" in host_name:
                host_name = host_name.split("(")[0]
            node_name = all_datas.select_one(f"span#form1\:dataTable1\:{index}\:txt_nameCol > span").text.strip()
            node_ip = all_datas.select_one(f"a#form1\:dataTable1\:{index}\:lnk_ipCol").text.strip()
            node_mac = all_datas.select_one(f"span#form1\:dataTable1\:{index}\:txt_macCol2").text.strip()
            node_platform = all_datas.select_one(f"a#form1\:dataTable1\:{index}\:lnk_platformCol")
            node_status = all_datas.select_one(f"span#form1\:dataTable1\:{index}\:txt_nodestatCol > i")["title"].strip()
            results.append({
                "host_name": host_name,
                "node_name": node_name,
                "node_ip": node_ip,
                "node_mac": node_mac,
                "node_platform": node_platform,
                "node_status": node_status
            })
        return results
    
    """
        Returned Data Format
        {
            "total_sensor_counts": <total_sensor_counts>,
            "active_sensor_counts": <active_sensor_counts>,
            "inactive_sensor_counts": <inactive_sensor_counts>
        }
    """
    def get_sensor_counts(self):
        if not self.__session:
            return False
        
        response = self.__session.get(parse.urljoin(self.__base_url, "/mc2/faces/monitor/nodeMgmt.xhtml?nid=All&genidev=2"), verify=False)
        if response.status_code != 200:
            return False
        
        soup = BeautifulSoup(response.text, "html.parser")
        all_datas = soup.select_one("tbody#form1\:dataTable1_data")
        total_sensor_counts = len(all_datas.select("td.checkcol"))
        
        response = self.__session.get(parse.urljoin(self.__base_url, "/mc2/faces/monitor/nodeMgmt.xhtml?nid=All&genidev=2&active=1"), verify=False)
        if response.status_code != 200:
            return False
        
        soup = BeautifulSoup(response.text, "html.parser")
        all_datas = soup.select_one("tbody#form1\:dataTable1_data")
        active_sensor_counts = len(all_datas.select("td.checkcol"))
        
        response = self.__session.get(parse.urljoin(self.__base_url, "/mc2/faces/monitor/nodeMgmt.xhtml?nid=All&genidev=2&active=0"), verify=False)
        if response.status_code != 200:
            return False
        
        soup = BeautifulSoup(response.text, "html.parser")
        all_datas = soup.select_one("tbody#form1\:dataTable1_data")
        inactive_sensor_counts = len(all_datas.select("td.checkcol"))
        
        return {
             "total_sensor_counts": total_sensor_counts,
             "active_sensor_counts": active_sensor_counts,
             "inactive_sensor_counts": inactive_sensor_counts
        }
    
    """
        Returned Data Format
        {
            "node_name": <node_name>,
            "node_ip": <node_ip>,
            "node_mac": <node_mac>,
            "node_last_active_time": <node_last_active_time>,
        }
    """
    def get_inactive_sensor(self):
        results = []
        if not self.__session:
            return False
        
        response = self.__session.get(parse.urljoin(self.__base_url, "/mc2/faces/monitor/nodeMgmt.xhtml?nid=All&genidev=2&active=0"), verify=False)
        if response.status_code != 200:
            return False
        
        soup = BeautifulSoup(response.text, "html.parser")
        all_datas = soup.select_one("tbody#form1\:dataTable1_data")
        data_counts = len(all_datas.select("td.checkcol"))
        node_row_key_list = all_datas.select("input[id$=rowkey]")
            
        for index in range(data_counts):
            node_id = node_row_key_list[index]["value"].split(",")[1]
            node_detail_url = f"/mc2/rest/nodes/{node_id}?v=2&l=ko"
            response = self.__session.get(parse.urljoin(self.__base_url, node_detail_url), verify=False)
            if response.status_code != 200:
                node_last_active_time = None
            else:
                node_detail_information = response.json()
                node_name = node_detail_information["node"]["data"]["nl_name"]
                if "(" in node_name:
                    node_name = node_name.split("(")[0].strip()
                node_ip = node_detail_information["node"]["data"]["nl_ipstr"]
                node_mac = node_detail_information["node"]["data"]["nl_mac"]
                node_last_active_time = node_detail_information["node"]["data"]["nl_lastactive"]
                node_last_active_time = datetime.fromtimestamp(node_last_active_time // 1000).strftime("%Y-%m-%d %H:%M:%S")
            
            results.append({
                "node_name": node_name,
                "node_ip": node_ip,
                "node_mac": node_mac,
                "node_last_active_time": node_last_active_time
            })

        return results
    
    def get_not_managemnet_node_on_war_network(self, period="week", ip="80.0.0.0-99.255.255.255", description="비관리 노드 감지됨"):
        if not self.__session:
            return False
        
        partial_url = f"/mc2/rest/logs?page=1&pageSize=255&logschema=auditlog&auditlogTypes=NODE&periodType={period}&ip={ip}&description={parse.quote(description)}&l=ko"
        response = self.__session.get(parse.urljoin(self.__base_url, partial_url), verify=False)
        if response.status_code != 200:
            return False
        
        return response.json()["result"]